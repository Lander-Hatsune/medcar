#pragma once

namespace OledPin {
  const auto SCL = 21;
  const auto SDA = 20;
}

void disp(char s[]);

