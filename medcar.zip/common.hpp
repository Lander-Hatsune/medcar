#pragma once
const auto BAUDRATE = 9600;
